Welcome to PageRecommendationSystem software, please read the following instruction guide to use this software.

Requirements:
1. Java environment(jdk 1.8)
2. Server environment (Tomcat Server v7.0)

About some files present:
1. Web Content -> 3 html files namely 1.html, 2.html, 3.html:   are simple web pages which use this software for recommending themselves.
2. Web Content -> pageRecommend.js:   is a javascript file, when attached with a web page will allow that URL to be recommended; 1.html, 2.html, 3.html use this js file by a script tag.
3. Web Content -> recommendOutput.html:   when opened this file will help to produce final output.
4. src -> addSession, closeSession, calcRecommend, QuickSortIt: are java servlets that perform server side functions to produce results.

To run this software (PageRecommendationSystem), please follow this instructions:-
1. Add your web page(s)(say index.html) that you want to be recommended to 'web content' directory (by default 1.html, 2.html, 3.html are already present as an example).
2. To index.html add <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
3. To these pages (index.html) add a script tag linking 'pageRecommend.js' here, that is add <script src="pageRecommend.js">
4. Run whole module on a server (preferrably Tomcat v7.0).
5. Use all your web pages normally for some time and let system store some data.
6. When you want to produce recommendation results, run recommendOutput.html, a file named "TimeRecords.txt" will be created on server, which stores all recommended URL(s) ordered in descending values.
7. Open "TimeRecords.txt" in your default Server file storage directory to see final recommendations.

Thank You.
-Manan Gupta.