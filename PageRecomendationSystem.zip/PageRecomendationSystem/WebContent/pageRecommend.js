/**
 * author: @dell_manan
 */
var visible = true;
function createSession(){
	$.get("addSession", {"url": window.location.href},function(){
		});
    visible = true;
};
function closeSession(){
	$.get("closeSession", function(){
		});
};
window.onpageshow = createSession();
window.onbeforeunload = function () {
	closeSession();
	visible = false;
	};

document.addEventListener("visibilitychange", event => {
	  if (document.visibilityState == "visible") {
	    createSession();
	  } else {
		  if(visible)
	    closeSession();
	  }
	});