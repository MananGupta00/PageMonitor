
public class QuickSortIt {
	
	 int partition(String urls[], int arr[], int low, int high) 
	    { 
	        int pivot = arr[high];
	        int i = (low-1);
	        for (int j=low; j<high; j++) 
	        { 
	            if (arr[j] > pivot) 
	            { 
	                i++; 
	                int temp = arr[i];
	                String tempStr = urls[i];
	                arr[i] = arr[j];
	                urls[i] = urls[j];
	                arr[j] = temp; 
	                urls[j] = tempStr;
	            } 
	        } 
	        int temp = arr[i+1];
	        String tempStr = urls[i+1];
	        arr[i+1] = arr[high]; 
	        urls[i+1] = urls[high];
 	        arr[high] = temp;
 	        urls[high] = tempStr;
	        return i+1; 
	    } 


	    void sort(String urls[],int arr[], int low, int high)
	    {
	        if (low < high)
	        {
	            int pi = partition(urls, arr, low, high);

	            sort(urls,arr, low, pi-1);
	            sort(urls,arr, pi+1, high); 
	        }
	    }

	    void printArray(String urls[],int arr[]) 
	    { 
	        int n = arr.length; 
	        for (int i=0; i<n; ++i) 
	            System.out.print(urls[i]+ " " +arr[i]+" ,"); 
	        System.out.println(); 
	    } 
}
