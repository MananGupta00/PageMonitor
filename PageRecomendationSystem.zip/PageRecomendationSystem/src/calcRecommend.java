
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class calcRecommend
 */
@WebServlet("/calcRecommend")
public class calcRecommend extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String[] urls= new	String[100];
	int[] times = new int[100];
	int n;
	
	boolean readRecords(){
		try {
		      File myObj = new File("TimeRecords.txt");
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        int timeIndex = data.indexOf(",TIME:");
		        urls[n] = data.substring(4, timeIndex);
		        times[n++] = Integer.parseInt(data.substring(timeIndex+6));
		        System.out.println("read:"+ urls[n-1]+ times[n-1]+ "  n="+n);
		      }
		      myReader.close();
		      return true;
		    } catch (Exception e) {
		    	String err = e.getMessage();
		      System.out.println("An error occurred. "+ err);
		      if(err.equals("No line found") || err.equals("TimeRecords.txt (The system cannot find the file specified)"))
				{
					System.out.println("ignoring error(file will be created)");
					return true;
				}
		      return false;
		    }
	}
	
	void storeRecords(){
		try {
	    		FileWriter out=  new FileWriter("TimeRecords.txt",false); 
	      for(int i=0; i < n; i++){
            out.write("URL:"+ urls[i] + ",TIME:"+times[i]+"\r\n");
  	      	System.out.println("storing:  URL:"+ urls[i] + " ,TIME:"+times[i]);
            }
            out.close(); 
	      System.out.println("records stored successfully");
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LocalTime testTime1 = java.time.LocalTime.now();
		try {
			n=0;
			File myObj = new File("entries.txt");
		      Scanner myReader = new Scanner(myObj);
				if((!myReader.hasNextLine() || !readRecords())){
					myReader.close();
					return;
				}
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        int ipIndex= data.indexOf(",IP:");
		        String url = data.substring(4, ipIndex);
		        int timeIndex = data.indexOf(",TIME:");
		        int time = Integer.parseInt(data.substring(timeIndex + 6));
		        int i;
		        for(i=0; i < n; i++){
		        	if(url.equals(urls[i])){
		        		times[i] = times[i] + time;
		        		System.out.println("Added" + url+ "	"+times[i]+"  n="+n);
		        		break;
		        	}
		        }
		        if(i==n){	//new url
		        urls[n] = url;
		        System.out.println("New Entry: "+ url+"	"+ time+"  n="+n);
		        times[n++] = time;
		        System.out.println("New Entry: "+ url+"	"+ time+"  n="+n);
		        }
		      }
		      FileWriter out = new FileWriter(myObj);
		      	out.write("");
		      	out.close();
		      myReader.close();
		      QuickSortIt sortObj = new QuickSortIt();
		      sortObj.sort(urls,times, 0, n-1);
		      storeRecords();
		    } catch (Exception e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		LocalTime testTime2 =  java.time.LocalTime.now();
		System.out.println("Time Before process: "+ testTime1+ "\nAfter: "+testTime2);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
