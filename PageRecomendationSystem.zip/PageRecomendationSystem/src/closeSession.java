

import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter; 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/closeSession")
public class closeSession extends HttpServlet {
	int hrLimit = 0, minLimit= 0 ;
	private static final long serialVersionUID = 1L;
	
	void cleanUp(HttpSession session){
		session.invalidate();
	}
	void makeEntry(String url, String ip, int hr, int min, int sec){
		try {
				sec= sec+ min*60 + hr*60;
		      BufferedWriter out = new BufferedWriter( 
		    		  new FileWriter("entries.txt",true)); 
	            out.write("URL:"+ url + ",IP:" + ip + ",TIME:"+sec+"\n"); 
	            out.close(); 
		      System.out.println("made entry for "+ url+ "\nTime elapsed:"+ hr +":"+min+":"+sec);
		    } catch (IOException e) {
		      e.printStackTrace();
		    }

	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		String ip;
		try{ip= session.getAttribute("IP").toString();
		
		String time = session.getAttribute("StartTime").toString();
		String startDate = session.getAttribute("StartDate").toString();
		String url = session.getAttribute("URL").toString();

		int starthr =  Integer.parseInt(time.substring(0,2));
		int startmin = Integer.parseInt(time.substring(3,5));
		int startsec = Integer.parseInt(time.substring(6,8));

		String endTime= java.time.LocalTime.now().toString();
		String endDate= java.time.LocalDate.now().toString();

		int endhr = Integer.parseInt(endTime.substring(0,2));
		int endmin = Integer.parseInt(endTime.substring(3,5));
		int endsec = Integer.parseInt(endTime.substring(6,8));
		int hr,min;
		int sec;
		boolean isDateSame = false;
		
		if(startDate.equals(endDate))
			isDateSame = true;

		if(starthr>endhr){
			endhr= endhr+24;
			if(startmin> endmin){
				startmin= startmin- endmin;
				endmin = 60;
				endhr= endhr -1;
				if(startsec > endsec){
					endmin= endmin - 1;
					startsec= startsec- endsec;
					endsec= 60;
				}
			}	else if(startmin == endmin && startsec > endsec){
					endhr--;
					startsec= startsec- endsec;
					endsec= 60;
					endmin= 60 + startmin;
			}
		}
		else if(startmin > endmin)
			endmin= endmin+60;
		else if(isDateSame!= true){
			this.cleanUp(session);
			return;
		}
	
		if(startsec > endsec && isDateSame){
			endmin--;
			startsec= startsec- endsec;
			endsec= 60;
		}
		hr= endhr - starthr;
		min= endmin - startmin;
		sec= endsec- startsec;
		if(hr<0 || min<0 || sec < 0){
			// printing to debug
			System.out.println("Start Time: "+ time + "\nStartDate: "+ startDate);
			System.out.println("End Time: "+ endTime + "\nEndDate: "+ endDate);
			System.out.println("hr : "+ hr + ", min : "+ min+ ", sec : " + sec);
			return;
		}

		if(minLimit!=0 || hrLimit!=0)
			{
				if(hr >= hrLimit || (min >= minLimit && hr== hrLimit)){
					this.cleanUp(session);
					return;
				}
			}
		this.makeEntry(url, ip, hr, min, sec);
		}	catch(Exception e){return;}
		this.cleanUp(session);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
